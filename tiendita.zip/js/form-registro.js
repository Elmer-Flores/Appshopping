

function validarCampo(id) {
    const campo = document.getElementById(id).value;
    if (campo != null && campo != undefined && campo != "" && campo != " ") {
        return campo;
    }
    return false;
}

function validarForm(idForm, listaCampos) {
    const formulario = document.getElementById(idForm);
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();
        let fallos = false;
        
        for ( let indice in listaCampos ) {
            if ( validarCampo(listaCampos[indice]) === false) {
                fallos = true;
            }
        };
        
        return fallos;
    })
}


function validarFormRegistro() {
    // let campos = ["nombreRegistro", "claveRegistro", "emailRegistro"];
    // let validacion = validarForm("formRegistro", campos);
    
    // if (validacion === false) {
    //     let usuario = new Usuario(campos[0], campos[1], campos[2]);
    //     let respuesta = usuario.registrar();
    //     if (respuesta) {
    //         // formulario.reset();
    //         window.location = "index.html";
    //     }
    // } else {
    //     console.log("No has completado bien los datos...");
    // }
    const formulario = document.getElementById("formRegistro");
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();
        let nombre = validarCampo("nombreRegistro");
        let email = validarCampo("emailRegistro");
        let clave = validarCampo("claveRegistro");
        if ( email != false && clave != false && nombre != false ) {
            let usuario = new Usuario(nombre, clave, email);
            let respuesta = usuario.registrar();
            if ( respuesta ) {
                formulario.reset();
                window.location = "index.html";
            } 
        } else {
            console.log("No has completado bien los datos...");
        }
    })
}

document.addEventListener("DOMContentLoaded", () => {
    validarFormRegistro();
});
