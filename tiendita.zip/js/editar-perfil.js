
function main() {
    if (sessionStorage.getItem("UserLogin")) {
        subLista("subListaCate", true);
        subLista("subListaSesion", false);
        cargarFotoPerfil();
        cerrarSesionNav();
        cargarDatos();
        imagenDeVistaPrevia();
        validarForm();
    } else {
        window.location = "index.html";
    }
}

function imagenDeVistaPrevia() {
    let anterior;
    // const form = document.getElementById("form");
    const botonImagen = document.getElementById("imagenFoto");
    const imagen = document.getElementById("imagenPrevia");
    botonImagen.addEventListener("change", (e) => {
        anterior = imagen.src;
        try{            
            let reader = new FileReader();
            reader.readAsDataURL(e.target.files[0]);
            reader.addEventListener("load", () => {
                imagen.src = reader.result;
            });
        }catch (error){
            imagen.src = anterior;
        }
    });
}



function cargarDatos() {
    let dataUser = JSON.parse(sessionStorage.getItem("UserLogin"));
    // let usuarios = JSON.parse(localStorage.getItem("Users"));
    const nombre = document.getElementById("nombre");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const imagenPrevia = document.getElementById("imagenPrevia");
    nombre.value = dataUser["nombre"];
    email.value = dataUser["email"];
    password.value = dataUser["clave"];
    imagenPrevia.src = dataUser["fotoPerfil"];
}

function validarForm() {
    const form = document.getElementById("form");
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        let nombre = validarCampo("nombre");
        let email = validarCampo("email");
        let clave= validarCampo("password");
        const imagen = document.getElementById("imagenPrevia");
        let dataUser = JSON.parse(sessionStorage.getItem("UserLogin"));
        let usuarios = JSON.parse(localStorage.getItem("Users"));
        
        if ( nombre != false && email != false && clave != false ) {
            try{                
                dataUser["nombre"] = nombre;
                dataUser["email"] = email;
                dataUser["clave"] = clave;
                dataUser["fotoPerfil"] = imagen.src;

                usuarios[dataUser["id"]]["nombre"] = nombre;
                usuarios[dataUser["id"]]["email"] = email;
                usuarios[dataUser["id"]]["clave"] = clave;
                usuarios[dataUser["id"]]["fotoPerfil"] = imagen.src;
                
                console.log("Has modificado un producto...");
                form.reset();
                sessionStorage.setItem("UserLogin", JSON.stringify(dataUser));
                localStorage.setItem("Users", JSON.stringify(usuarios));
                window.location = "tu-perfil.html";
            } catch (error){
                imagen.src = "img/icono/producto.PNG";
            }
        } else {
            console.log("No has completado bien los campos...");
        }
    });
}


function validarCampo(id) {
    const campo = document.getElementById(id).value;
    if ( campo != null && campo != undefined && campo != "" && campo != " " ) {
        return campo;
    }
    return false;
}



function actualizar() {

}




document.addEventListener("DOMContentLoaded", () => {
    main();
})