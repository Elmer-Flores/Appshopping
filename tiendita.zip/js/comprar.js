
function main() {
    if (sessionStorage.getItem("UserLogin")) {
        if (localStorage.getItem("productoSeleccionado")) {
            cargarDatos();
            subLista("subListaCate", true);
            subLista("subListaSesion", false);
            cargarFotoPerfil();
            verPerfilVendedor();
            cerrarSesionNav();
            volverAtras();
            verPerfilComentador();
        } else {
            window.location = "productos.html";
        }
    } else {
        window.location = "index.html";
    }
}

function cargarDatos() {
    let usuariosRegistrados = JSON.parse(localStorage.getItem("Users"));
    const mainCont = document.querySelector(".contenedor");
    mainCont.innerHTML = "";
    const templateOriginal = document.getElementById("templateCompra").content;
    const template = templateOriginal.cloneNode(true);
    const fragmento = document.createDocumentFragment();
    let producto = localStorage.getItem("productoSeleccionado");
    producto = JSON.parse(producto);

    let idUser = producto["id_vendedor"];
    
    // console.log(template);
    template.querySelector("#personaVendedorProducto").dataset.idVendedor = idUser; 
    template.querySelector(".imagenPersonaVendedor").src = usuariosRegistrados[idUser]["fotoPerfil"];
    template.querySelector("#personaVendedorProducto").textContent = usuariosRegistrados[idUser]["nombre"];

    template.querySelector(".producto-seleccionado").dataset.idProducto = producto["id"];
    template.querySelector(".imagen-producto").src = producto["imagen_producto"];
    template.querySelector(".fecha-info").textContent = `Fecha de subida: ${producto["fecha_subida"]}`;
    template.querySelector(".nombre-producto").textContent = producto["nombre"];
    template.querySelector(".precio-producto").textContent = `$${producto["precio"]}`;
    template.querySelector(".categoria-producto").textContent = producto["categoria"];
    template.querySelector(".cantidad-producto").textContent = `Cantidad: ${producto["cantidad"]}`;
    template.querySelector(".texto-descripcion").textContent = producto["descripcion"];
    fragmento.appendChild(template);
    mainCont.appendChild(fragmento);
    // console.log(producto);
    comprar();
    volverAtras();
    comentar();
    cargarComentarios();
    verPerfilComentador();
}


function realizarCompra(productoCompra) {
    const cuerpoPag = document.getElementById("cuerpoPag");
    const template = document.getElementById("templateModal").content.cloneNode(true);
    const fragemento = document.createDocumentFragment();
    template.querySelector(".modal").dataset.idProducto = productoCompra["id"];
    template.querySelector(".imagen-productoModal").src = productoCompra["imagen_producto"];
    template.querySelector(".nombre-productoModal").textContent = productoCompra["nombre"];
    template.querySelector("#precioOr").textContent = productoCompra["precio"];
    template.querySelector(".inputModal").value = 1;
    template.querySelector(".costoDinero").textContent = `$${productoCompra["precio"]}`;
    template.appendChild(fragemento);
    cuerpoPag.appendChild(template);
}

function cambioCantidad() {
    const input = document.getElementById("cantidad-modal");
    const precio = document.querySelector("#precioOr");
    const costo = document.querySelector("#costoTotal");
    input.addEventListener("keyup", (e) => {
        // console.log(input.value);
        // console.log(e.key);
        let res = +input.value * +precio.textContent;
        costo.textContent = `$${res}`;
    });
}

function accionesModal() {
    const btnComprar = document.getElementById("btnCompraModal");
    const btnCancelar = document.getElementById("btnCancelar");
    const cuerpoPag = document.getElementById("cuerpoPag");
    const modalCompra = document.querySelector(".contenedor-modal");
    btnCancelar.addEventListener("click", () => {
        cuerpoPag.removeChild(modalCompra);
        // return false;
    });
    btnComprar.addEventListener("click", () => {
        const input = document.getElementById("cantidad-modal");
        cuerpoPag.removeChild(modalCompra);
        let producto = localStorage.getItem("productoSeleccionado");
        producto = JSON.parse(producto);

        let productos = localStorage.getItem("ProductosSubidos");
        productos = JSON.parse(productos);
        let user = sessionStorage.getItem("UserLogin");
        user = JSON.parse(user);
        let persona = new Usuario(user["nombre"], user["clave"], user["email"]);

        producto["cantidad"] = +producto["cantidad"] - (+input.value);
        let resultado = persona.verProductos();

        for (let indice in resultado) {
            if (resultado[indice]["id"] == producto["id"]) {
                resultado[indice]["cantidad"] = producto["cantidad"];
                producto["cantidad"] = resultado[indice]["cantidad"];
            }
        }
        
        if (producto["cantidad"] <= 0) {
            // persona.eliminarProducto(producto["id"]);
            let cantidadVal = 0;
            let nuevoOrden = new Object();
            
            for (let indice in resultado) {
                cantidadVal += 1;
                if (resultado[indice]["cantidad"] > 0) {
                    nuevoOrden[indice] = resultado[indice];
                }
            }
            
            console.log("Ya no hay más productos...");            
            localStorage.removeItem("productoSeleccionado");
            localStorage.setItem("ProductosSubidos", JSON.stringify(nuevoOrden));
            
            if (cantidadVal == 1) {
                localStorage.removeItem("ProductosSubidos");
            }
            
            // window.location = "producto-solitario.html";
            window.location.reload();
        } else {
            
            localStorage.setItem("productoSeleccionado", JSON.stringify(producto));
            localStorage.setItem("ProductosSubidos", JSON.stringify(resultado));
            cargarDatos();
        }

        persona.guardarHistorial(producto["id_vendedor"], producto["id"], "Compras", (+input.value) );
    });
}

function comprar() {
    const btnComprar = document.getElementById("btnComprar");
    btnComprar.addEventListener("click", () => {
        // console.log("Comprado...");
        let producto = localStorage.getItem("productoSeleccionado");
        producto = JSON.parse(producto);
        realizarCompra(producto);
        cambioCantidad();
        accionesModal();
    });
}

function verPerfilVendedor(){
    const link = document.getElementById("personaVendedorProducto");
    link.addEventListener("click", () => {
        let usuariosRegistrados = JSON.parse(localStorage.getItem("Users"));
        let userVer = usuariosRegistrados[link.dataset.idVendedor];
        console.log(userVer);
        localStorage.setItem("PerfilSeleccionado", JSON.stringify(userVer));
        window.location = "perfil-seleccionado.html";
    });
}

function volverAtras(){
    const btnlink = document.getElementById("volverAtrasVentana");
    btnlink.addEventListener("click", () => {
        window.location = "productos.html";
    });
}

function verPerfilComentador() {
    const comments = document.querySelectorAll(".personaComentador");
    comments.forEach( elemento => {
        elemento.addEventListener("click", () => {
            let usuariosRegistrados = JSON.parse(localStorage.getItem("Users"));
            let tu = JSON.parse(sessionStorage.getItem("UserLogin"));
            let userVer = usuariosRegistrados[elemento.dataset.idComentador];
            console.log(userVer);
            if ( elemento.dataset.idComentador == tu["id"] ) {
                window.location = "tu-perfil.html";
            } else {
                localStorage.setItem("PerfilSeleccionado", JSON.stringify(userVer));
                window.location = "perfil-seleccionado.html";
            }
        });
    });
}

function comentar() {
    const btnComentar = document.querySelector(".btn-Comentar");
    btnComentar.addEventListener("click", () => {
        const coment = document.getElementById("comment");
        let producto = JSON.parse(localStorage.getItem("productoSeleccionado"));
        let user = JSON.parse(sessionStorage.getItem("UserLogin"));
        let id = 1;
        let tiempoActual = new Date();
        tiempoActual = `${tiempoActual.getDate()}/${tiempoActual.getMonth() + 1}/${tiempoActual.getFullYear()} a las ${tiempoActual.getHours()}:${tiempoActual.getMinutes()}`;
        let comentario = {
            "idComentario": id,
            "usuario": user["id"],
            "contenido": coment.value,
            "producto": producto["id"],
            "fecha": tiempoActual
        };
        if ( localStorage.getItem("comentarios") ) {
            let comentarios = JSON.parse(localStorage.getItem("comentarios"));
            
            for ( let indice in comentarios ) {
                id = comentarios[indice]["idComentario"];
            }
            
            id = id + 1;
            comentario["idComentario"] = id;
            comentarios[id] = comentario; 
            localStorage.setItem("comentarios", JSON.stringify(comentarios));
        } else {
            let comentarios = new Object();
            id = 1;
            comentarios[id] = comentario;
            localStorage.setItem("comentarios", JSON.stringify(comentarios));
        }
        // console.log(coment.value);
        cargarComentarios();
        coment.value = "";
    });
}

function cargarComentarios(){
    const padre = document.querySelector(".zona-comentarios");
    padre.innerHTML = "";
    let comprobante = document.querySelector(".producto-seleccionado").dataset.idProducto;
    if ( localStorage.getItem("comentarios") ) {
        let comentarios = JSON.parse( localStorage.getItem("comentarios") );
        const fragmento = document.createDocumentFragment();
        
        for ( let indice in comentarios ) {
            let usuarios = JSON.parse(localStorage.getItem("Users"));
            let comentario = comentarios[indice];
            if( comentario["producto"] == comprobante ) {
                const template = document.getElementById("templateComentario").content.cloneNode(true);
                template.querySelector(".personaComentador").textContent = usuarios[comentario["usuario"]]["nombre"]; 
                template.querySelector(".imagenPersonaComentador").src = usuarios[comentario["usuario"]]["fotoPerfil"]; 
                template.querySelector(".p-texto-co").textContent = comentario["contenido"];
                template.querySelector(".personaComentador").dataset.idComentador = usuarios[comentario["usuario"]]["id"];
                template.querySelector(".fecha-comentada").textContent = comentario["fecha"];
                fragmento.appendChild(template);
            }
        }
        
        padre.appendChild(fragmento);
    } else {
        console.log("no hay comentarios");
    }
}


document.addEventListener("DOMContentLoaded", () => {
    main();
})