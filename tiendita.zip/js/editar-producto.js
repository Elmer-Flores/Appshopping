
function cancelar() {
    const btnCancelar = document.getElementById("btnCancelarFormEditar");
    btnCancelar.addEventListener("click", () => {
        localStorage.removeItem("ProductoModificar");
        window.location = "tu-perfil.html";
    });
}

function cargarDataAntes(){
    let productoModificar = JSON.parse(localStorage.getItem("ProductoModificar"));
    // let usuario = JSON.parse(sessionStorage.getItem("UserLogin"));

    document.getElementById("nombreProducto").value = productoModificar["nombre"];
    document.getElementById("categoriaProducto").value = productoModificar["categoria"];
    document.getElementById("precioProducto").value = productoModificar["precio"];
    document.getElementById("cantidadProducto").value = productoModificar["cantidad"];
    document.getElementById("descripcionProducto").value = productoModificar["descripcion"];
    document.getElementById("imagenPrevia").src = productoModificar["imagen_producto"];
}

function main() {
    if ( sessionStorage.getItem("UserLogin") ) {
        let usuario = sessionStorage.getItem("UserLogin");
        usuario = JSON.parse(usuario);
        subLista("subListaCate", true);
        subLista("subListaSesion", false);
        cargarFotoPerfil();
        cerrarSesionNav();
        if ( localStorage.getItem("ProductoModificar") ) {
            cargarDataAntes();
            imagenDeVistaPrevia();
            realizarForm();
            cancelar();
            eliminarProducto();
        } else {
            try {
                window.history.back();
            } catch (error) {
                window.location = "index.html";
            }
        }
    } else {
        window.location = "index.html";
    }
} 


// FUNCIONES PARA EL FORMULARIO
function imagenDeVistaPrevia() {
    let anterior;
    const form = document.getElementById("formPublicacion");
    const botonImagen = document.getElementById("imagenProducto");
    const imagen = document.getElementById("imagenPrevia");
    botonImagen.addEventListener("change", (e) => {
        anterior = imagen.src;
        try{            
            let reader = new FileReader();
            reader.readAsDataURL(e.target.files[0]);
            reader.addEventListener("load", () => {
                imagen.src = reader.result;
            });
        }catch (error){
            imagen.src = anterior;
        }
    });
}

function validarCampo(id) {
    const campo = document.getElementById(id).value;
    if ( campo != null && campo != undefined && campo != "" && campo != " " ) {
        return campo;
    }
    return false;
}


function realizarForm(){
    const formulario = document.getElementById("formPublicacion");
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();
        let productoModificar = JSON.parse(localStorage.getItem("ProductoModificar"))
        let usuario = JSON.parse(sessionStorage.getItem("UserLogin"));
        let userObj = new Usuario(usuario["nombre"], usuario["clave"], usuario["email"]);
        userObj.iniciarSesion();
        let nombre = validarCampo("nombreProducto");
        let precio = validarCampo("precioProducto");
        let categoria = validarCampo("categoriaProducto");
        let descripcion = validarCampo("descripcionProducto");
        let cantidad = validarCampo("cantidadProducto");
        let imagen = document.getElementById("imagenPrevia").src;
        if ( nombre != false && precio != false && categoria != false  && descripcion != false && cantidad != false) {
            try{                
                userObj.editarProducto(productoModificar["id"], "nombre", nombre, "ProductosSubidos");
                userObj.editarProducto(productoModificar["id"], "precio", precio, "ProductosSubidos");
                userObj.editarProducto(productoModificar["id"], "cantidad", cantidad, "ProductosSubidos");
                userObj.editarProducto(productoModificar["id"], "descripcion", descripcion, "ProductosSubidos");
                userObj.editarProducto(productoModificar["id"], "categoria", categoria, "ProductosSubidos");
                userObj.editarProducto(productoModificar["id"], "imagen_producto", imagen, "ProductosSubidos");
                console.log("Has modificado un producto...");
                formulario.reset();
                localStorage.removeItem("ProductoModificar");
                window.location = "tu-perfil.html";
            } catch (error){
                imagen = "img/icono/producto.PNG";
            }
        } else {
            console.log("No has completado bien los campos...");
        }
    });
}

function eliminarProducto() {
    const btnEliminar = document.getElementById("btnEliminarProducto");
    btnEliminar.addEventListener("click", () => {
        let productoModificar = JSON.parse(localStorage.getItem("ProductoModificar"));
        let productos = JSON.parse(localStorage.getItem("ProductosSubidos"));
        let comentarios = JSON.parse(localStorage.getItem("comentarios"));
        let result = new Object();
        let actualizacionComentarios = new Object();
        
        for ( let indice in productos ) {
            if ( productos[indice]["id"] != productoModificar["id"] ) {
                result[indice] = productos[indice];
            }
        }
        
        for ( let indice in comentarios ) {
            if ( comentarios[indice]["producto"] != productoModificar["id"] ) {
                actualizacionComentarios[indice] = comentarios[indice];
            }
        }
        
        localStorage.setItem("comentarios", JSON.stringify(actualizacionComentarios));
        localStorage.setItem("ProductosSubidos", JSON.stringify(result));
        window.location =" tu-perfil.html";
    });
}


document.addEventListener("DOMContentLoaded",  () => {
    main();
})