

function validarCampo(id) {
    const campo = document.getElementById(id).value;
    if ( campo != null && campo != undefined && campo != "" && campo != " " ) {
        return campo;
    }
    return false;
}

function validarFormSesion() {
    const formulario = document.getElementById("formIniciarSesion");
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();
        let email = validarCampo("emailSesion");
        let clave = validarCampo("claveSesion");
        if ( email != false && clave != false ) {
            let usuario = new Usuario("", clave, email);
            let respuesta = usuario.iniciarSesion();
            if ( respuesta ) {
                formulario.reset();
                window.location = "productos.html";
            } 
        } else {
            console.log("No has completado bien los datos...");
        }
    });
}



document.addEventListener("DOMContentLoaded", () => {
    validarFormSesion();
});
