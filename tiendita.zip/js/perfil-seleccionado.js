
function main() {
    if (sessionStorage.getItem("UserLogin")) {
        let userTemp = JSON.parse(sessionStorage.getItem("UserLogin"));
        cargarFotoPerfil();
        subLista("subListaCate", true);
        subLista("subListaSesion", false);
        cargarDatosPersonales();
        cerrarSesionNav();
        if (localStorage.getItem("ProductosSubidos")) {
            cargarDatos();
            seleccionProductos();
            let persona = new Usuario(userTemp["nombre"], userTemp["clave"], userTemp["email"]);
            persona.iniciarSesion();
        } else {
            console.log("No has subido ninguno todavia");
        }
    } else {
        window.location = "index.html";
    }
}


function cargarDatosPersonales() {
    let userLog = localStorage.getItem("PerfilSeleccionado");
    // let userLog = sessionStorage.getItem("UserLogin");
    userLog = JSON.parse(userLog);
    let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
    persona.iniciarSesion();

    const datosPerfil = document.querySelector(".tarjeta-perfil");
    const templateOriginalPerfil = document.getElementById("datosPerfil").content;
    const fragmentoPerfil = document.createDocumentFragment();
    const templatePerfil = templateOriginalPerfil.cloneNode(true);
    templatePerfil.querySelector(".nombre").textContent = userLog["nombre"];
    templatePerfil.querySelector(".email").textContent = userLog["email"];
    templatePerfil.querySelector(".fecha-subida").textContent = "Fecha de creación: " + userLog["fecha"];
    fragmentoPerfil.appendChild(templatePerfil);
    datosPerfil.appendChild(fragmentoPerfil);
}



function cargarDatos() {
    // let userLog = sessionStorage.getItem("UserLogin");
    // let userTemp = JSON.parse(sessionStorage.getItem("UserLogin"));
    let userLog = localStorage.getItem("PerfilSeleccionado");
    userLog = JSON.parse(userLog);
    let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
    persona.iniciarSesion();

    let productos = persona.verProductos(true);

    const mainCont = document.querySelector(".productos");
    mainCont.innerHTML = "";
    const templateOriginal = document.getElementById("templateProductoPerfil").content;
    const fragmento = document.createDocumentFragment();

    for (let indice in productos) {
        let producto = productos[indice];
        if (producto["id_vendedor"] == userLog["id"]) {
            const template = templateOriginal.cloneNode(true);
            template.querySelector(".producto").dataset.idProducto = producto["id"];
            template.querySelector(".imagen-producto").src = producto["imagen_producto"];
            template.querySelector(".titulo-info").textContent = producto["nombre"];
            template.querySelector(".precio-info").textContent = "$" + producto["precio"];
            fragmento.appendChild(template);
        }
    }

    mainCont.appendChild(fragmento);
    // let userTemp = JSON.parse(sessionStorage.getItem("UserLogin"));
    // persona = new Usuario(userTemp["nombre"], userTemp["clave"], userTemp["email"]);
    // persona.iniciarSesion();
}

function seleccionProductos() {
    const productos = document.querySelectorAll(".producto");
    productos.forEach(elemento => {
        elemento.addEventListener("click", () => {
            let productoPublicados = JSON.parse(localStorage.getItem("ProductosSubidos"));
            let idProductoSeleccionado = elemento.dataset.idProducto;
            // console.log(elemento.dataset.idProducto);
            console.log(productoPublicados[idProductoSeleccionado]);
            localStorage.setItem("productoSeleccionado", JSON.stringify(productoPublicados[idProductoSeleccionado]) );
            // localStorage.setItem("ProductoModificar", JSON.stringify(productoPublicados[idProductoSeleccionado]));
            window.location = "producto-solitario.html";
        });
    });
}

document.addEventListener("DOMContentLoaded", () => {
    main();
})