
function buscarProductos(campo, valorBucar) {
    // console.log(`Buscando por ${valorBucar}...`);
    let valid = 0;
    let usuario = JSON.parse(sessionStorage.getItem("UserLogin"));
    const person = new Usuario(usuario["nombre"], usuario["clave"], usuario["email"]);
    let results = person.busquedaAvanzada(campo, valorBucar, "ProductosSubidos");
    if (valorBucar == "Todos") {
        results = person.verProductos();
    }
    
    for ( let indice in results ) {
        if ( results[indice]["id_vendedor"] != usuario["id"] ) {
            valid++;
        }
    }
    
    if ( valid === 0 ) {
        return false;
    }
    
    return results;
}


// FUNCIONES PARA EL SLIDER DE PORTADA
let posSlider = 1;

// function administrar(capas, btnSLiders) {
//     btnSLiders.forEach(btnCont => {
//         btnCont.classList.add("btn-slider");
//         btnCont.classList.remove("btn-slider-seleccionado");
//     });
//     capas.forEach(elemento => {
//         elemento.classList.remove("capa-portada-seleccionada");
//         elemento.classList.add("capa-portada");
//         let cord = elemento.id;
//         if (cord === `img${posSlider}`) {
//             // console.log(elemento);
//             btnSLiders.forEach(btnCont => {
//                 if (btnCont.dataset.ide == posSlider) {
//                     btnCont.classList.add("btn-slider-seleccionado");
//                 }
//             });
//             elemento.classList.remove("capa-portada");
//             elemento.classList.add("capa-portada-seleccionada");
//         }
//     });
// }

// function moverseConstante() {
//     const btnSLiders = document.querySelectorAll(".btn-slider");
//     const capas = document.querySelectorAll(".capa-slider");
//     const automatico = setInterval( () => {
//         if (posSlider < 6) {
//             posSlider++;
//             // console.log(posSlider);
//             administrar(capas, btnSLiders);
//         } else {
//             posSlider = 1;
//             administrar(capas, btnSLiders);
//             // console.log(posSlider);
//             // console.log("No puedes desplazerta más para ese lado...");
//         }
//     }, 6000);

// }

// function slider() {
//     const capas = document.querySelectorAll(".capa-slider");
//     const btn = document.querySelector(".btn-siguiente-p");
//     const btn2 = document.querySelector(".btn-anterior-p");
//     const contLinea = document.getElementById("btn-sliders");
//     const btnSLiders = document.querySelectorAll(".btn-slider");
//     btn.addEventListener("click", () => {
//         if (posSlider < capas.length) {
//             posSlider++;
//             console.log(posSlider);
//             administrar(capas, btnSLiders);
//         } else {
//             posSlider = 1;
//             administrar(capas, btnSLiders);
//             // console.log(posSlider);
//             // console.log("No puedes desplazerta más para ese lado...");
//         }
//     });
//     btn2.addEventListener("click", () => {
//         if (posSlider > 1) {
//             posSlider--;
//             console.log(posSlider);
//             administrar(capas, btnSLiders);
//         } else {
//             posSlider = 6;
//             administrar(capas, btnSLiders);
//             // console.log(posSlider);
//             // console.log("No puedes desplazerta más para ese lado...");
//         }
//     });
//     contLinea.addEventListener("click", (e) => {
//         if (e.target.tagName == "SPAN") {
//             btnSLiders.forEach(btnCont => {
//                 btnCont.classList.add("btn-slider");
//                 btnCont.classList.remove("btn-slider-seleccionado");
//             });
//             capas.forEach(cap => {
//                 cap.classList.remove("capa-portada-seleccionada");
//                 cap.classList.add("capa-portada");
//                 if (cap.id == `img${e.target.dataset.ide}`) {
//                     posSlider = e.target.dataset.ide;
//                     // console.log(e.target);
//                     cap.classList.remove("capa-portada");
//                     cap.classList.add("capa-portada-seleccionada");
//                     e.target.classList.add("btn-slider-seleccionado");
//                 }
//             });
//         }
//     });
// }

function slider() {
    function administrar(capas, btnSLiders) {
        btnSLiders.forEach(btnCont => {
            btnCont.classList.add("btn-slider");
            btnCont.classList.remove("btn-slider-seleccionado");
        });
        capas.forEach(elemento => {
            elemento.classList.remove("capa-portada-seleccionada");
            elemento.classList.add("capa-portada");
            let cord = elemento.id;
            if (cord === `img${posSlider}`) {
                // console.log(elemento);
                btnSLiders.forEach(btnCont => {
                    if (btnCont.dataset.ide == posSlider) {
                        btnCont.classList.add("btn-slider-seleccionado");
                    }
                });
                elemento.classList.remove("capa-portada");
                elemento.classList.add("capa-portada-seleccionada");
            }
        });
    }
    const capas = document.querySelectorAll(".capa-slider");
    const btn = document.querySelector(".btn-siguiente-p");
    const btn2 = document.querySelector(".btn-anterior-p");
    const contLinea = document.getElementById("btn-sliders");
    const btnSLiders = document.querySelectorAll(".btn-slider");
    btn.addEventListener("click", () => {
        if (posSlider < capas.length) {
            posSlider++;
            console.log(posSlider);
            administrar(capas, btnSLiders);
        } else {
            posSlider = 1;
            administrar(capas, btnSLiders);
            // console.log(posSlider);
            // console.log("No puedes desplazerta más para ese lado...");
        }
    });
    btn2.addEventListener("click", () => {
        if (posSlider > 1) {
            posSlider--;
            console.log(posSlider);
            administrar(capas, btnSLiders);
        } else {
            posSlider = 6;
            administrar(capas, btnSLiders);
            // console.log(posSlider);
            // console.log("No puedes desplazerta más para ese lado...");
        }
    });
    contLinea.addEventListener("click", (e) => {
        if (e.target.tagName == "SPAN") {
            btnSLiders.forEach(btnCont => {
                btnCont.classList.add("btn-slider");
                btnCont.classList.remove("btn-slider-seleccionado");
            });
            capas.forEach(cap => {
                cap.classList.remove("capa-portada-seleccionada");
                cap.classList.add("capa-portada");
                if (cap.id == `img${e.target.dataset.ide}`) {
                    posSlider = e.target.dataset.ide;
                    // console.log(e.target);
                    cap.classList.remove("capa-portada");
                    cap.classList.add("capa-portada-seleccionada");
                    e.target.classList.add("btn-slider-seleccionado");
                }
            });
        }
    });
}

// function slider() {
//     const btnAnterior = document.querySelector(".btn-anterior-p");
//     const btnSiguiente = document.querySelector(".btn-siguiente-p");
//     const slider = document.querySelector(".slider");
//     const secciones = document.querySelectorAll(".capa-portada");
//     let ultimo = secciones[ secciones.length - 1 ];

//     slider.insertAdjacentElement("afterbegin", ultimo);

//     function siguiente() {
//         if ( posSlider < secciones.length ) {
//             posSlider = posSlider + 1;
//         } else {
//             posSlider = 1;
//         }
//         console.log(posSlider);
//         let primero = document.querySelectorAll(".capa-portada")[0];
//         slider.style.marginLeft = "-200%";
//         slider.style.transition = "all .5s";
//         setTimeout( () => {
//             slider.style.transition = "none";
//             slider.insertAdjacentElement("beforeend", primero);
//             slider.style.marginLeft = "-100%";
//         }, 500);
//         const btnLineas = document.querySelectorAll(".btn-slider");
//         btnLineas.forEach( elemento => {
//             elemento.classList.remove("btn-slider-seleccionado");
//         });
//         for ( let indice in btnLineas ) {
//             if ( indice == (posSlider - 1) ) {
//                 btnLineas[posSlider - 1].classList.add("btn-slider-seleccionado");
//                 console.log(btnLineas[posSlider - 1]);
//             }
//         }

//         // btnLineas[posSlider].classList.add("btn-slider-seleccionado");
//     }

//     function anterior() {
//         if ( posSlider > 1 ) {
//             posSlider = posSlider - 1;
//         } else {
//             posSlider = 6;
//         }
//         console.log(posSlider);
//         let secciones = document.querySelectorAll(".capa-portada");
//         let ultimo = secciones[ secciones.length - 1 ];
//         slider.style.marginLeft = "0";
//         slider.style.transition = "all .5s";
//         setTimeout( () => {
//             slider.style.transition = "none";
//             slider.insertAdjacentElement("afterbegin", ultimo);
//             slider.style.marginLeft = "-100%";
//         }, 500);
//         const btnLineas = document.querySelectorAll(".btn-slider");
//         btnLineas.forEach( elemento => {
//             elemento.classList.remove("btn-slider-seleccionado");
//         });
//         for ( let indice in btnLineas ) {
//             if ( indice == (posSlider - 1) ) {
//                 btnLineas[posSlider - 1].classList.add("btn-slider-seleccionado");
//                 console.log(btnLineas[posSlider - 1]);
//             }
//         }
//     }

//     function moverse(tiempo, largo) {
//         const intervalo = setInterval(() => {
        
//             let secciones = document.querySelectorAll(".capa-portada");
//             let primero = secciones[0];
//             let ultimo = secciones[ secciones.length - 1 ];
//             // slider.style.marginLeft = `-${largo}00%`;
//             posSlider += 1;
//             slider.style.marginLeft = `-200%`;
//             slider.style.transition = "all .5s";
//             setTimeout( () => {
//                 slider.style.transition = "none";
//                 // slider.insertAdjacentElement("afterbegin", ultimo);
//                 slider.insertAdjacentElement("beforeend", primero);
//                 // slider.style.marginLeft = `-${largo}00%`;
//                 slider.style.marginLeft = `-100%`;
//             }, tiempo * 200 );
        
//         }, largo * 300);
//         setTimeout(() => {
//             clearInterval(intervalo);
//         }, largo * 300 * largo );
//     }

//     function lineasBototnes() {
//         const btns = document.querySelectorAll(".btn-slider");
//         btns.forEach( elemento => {
//             elemento.addEventListener("click", () => {
//                 posSlider = Number(elemento.dataset.ide);
//                 console.log(posSlider);
//                 console.log(elemento);
//                 setTimeout( () => { 
//                     moverse(elemento.dataset.ide, elemento.dataset.ide);
//                 }, elemento.dataset.ide * 200);
//             });
//         });
//     }

    
//     btnSiguiente.addEventListener("click", () => {
//         siguiente();
//     });
    
//     btnAnterior.addEventListener("click", () => {
//         anterior();
//     });

//     lineasBototnes();
// }




function main() {
    // FUNCIONES PARA EL USUARIO
    if (sessionStorage.getItem("UserLogin")) {
        console.log("Bienvenido...");
        const productos = document.querySelector(".productos");
        let usuario = sessionStorage.getItem("UserLogin");
        usuario = JSON.parse(usuario);
        let nuevo = new Usuario(usuario["nombre"], usuario["clave"], usuario["email"]);
        // console.log(nuevo);
        if (localStorage.getItem("ProductosSubidos")) {
            let resultados = nuevo.verProductos();
            const template = document.getElementById("templateProducto").content;
            const fragmento = document.createDocumentFragment();
            // console.log(resultados);
            // console.log(template);

            for (let indice in resultados) {
                if (resultados[indice]["id_vendedor"] != usuario["id"]) {
                    const clon = template.cloneNode(true);
                    let producto = resultados[indice];
                    clon.querySelector(".producto").dataset.idProducto = producto["id"];
                    clon.querySelector(".imagen-producto").src = producto["imagen_producto"];
                    clon.querySelector(".titulo-info").textContent = producto["nombre"];
                    clon.querySelector(".precio-info").textContent = "$" + producto["precio"];
                    fragmento.appendChild(clon);
                }
            }

            productos.appendChild(fragmento);

        } else {
            console.log("No hay productos publicados...");
        }

        subLista("subListaCate", true);
        subLista("subListaSesion", false);
        cargarFotoPerfil();
        cerrarSesionNav();
        btnAdelanteCategorias("adelante-btn");
        btnAtrasCategorias("atras-btn");
        opcionesCategorias();
        slider();
        // moverseConstante();
        seleccionarProducto();
        buscador();
    } else {
        window.location = "index.html";
    }
}


function seleccionarProducto() {
    const productos = document.querySelectorAll(".producto");
    let usuario = sessionStorage.getItem("UserLogin");
    usuario = JSON.parse(usuario);
    let userLog = new Usuario(usuario["nombre"], usuario["clave"], usuario["email"]);
    productos.forEach(elemento => {
        elemento.addEventListener("click", () => {
            // console.log(elemento);
            let idProductoSelect = elemento.dataset.idProducto;
            // let nombre = elemento.querySelector(".titulo-info").textContent;
            // let precio = elemento.querySelector(".precio-info").textContent;
            // let img = elemento.querySelector(".imagen-producto").src;
            // console.log(idProducto, nombre, precio, img);
            let resultado = userLog.buscar("id", idProductoSelect, "ProductosSubidos");
            console.log(resultado);
            localStorage.setItem("productoSeleccionado", JSON.stringify(resultado));
            window.location = "producto-solitario.html";
        });
    });
}

// FUNCIONES PARA LA BARRA DE CATEGORIAS
let posCategorias = 0;

function btnAdelanteCategorias(id) {
    const btn = document.getElementById(id);
    btn.addEventListener("click", () => {
        const categorias = document.getElementById("opciones-categorias");
        const contOp = document.querySelector(".opciones");
        let anchoOpciones = calcularDistancia();
        let comparacion = anchoOpciones / (6 * 10);
        if (posCategorias < comparacion) {
            if (contOp.offsetWidth < 1133) {
                posCategorias += 14.2;
            }
            else if (contOp.offsetWidth < 1233) {
                posCategorias += 11.9;
            }
            else if (contOp.offsetWidth < 1333) {
                posCategorias += 11.5;
            } else {
                posCategorias += 10;
            }
            categorias.style.transform = `translateX(-${posCategorias}%)`;
            categorias.style.transition = "all .3s";
        }
    });
}

function btnAtrasCategorias(id) {
    const btn = document.getElementById(id);
    btn.addEventListener("click", () => {
        const categorias = document.getElementById("opciones-categorias");
        const contOp = document.querySelector(".opciones");

        if (posCategorias > 0) {

            if (contOp.offsetWidth < 1133) {
                posCategorias -= 14.2;
            }
            else if (contOp.offsetWidth < 1233) {
                posCategorias -= 11.9;
            }
            else if (contOp.offsetWidth < 1333) {
                posCategorias -= 11.5;
            } else {
                posCategorias -= 10;
            }

            if (posCategorias < 20) {
                posCategorias = 0;
            }
            categorias.style.transform = `translateX(-${posCategorias}%)`;
            categorias.style.transition = "all .3s";
        }
    });
}

function opcionesCategorias() {
    const listCategorias = document.getElementById("opciones-categorias");
    const opciones = document.querySelectorAll("#opciones-categorias > li > span");
    listCategorias.addEventListener("click", (e) => {
        if (e.target.tagName == "SPAN") {

            opciones.forEach(op => {
                op.classList.remove("seleccionado-categoria");
                op.classList.add("opcion-categoria");
            });

            // console.log(e.target);
            e.target.classList.remove("opcion-categoria");
            e.target.classList.add("seleccionado-categoria");
            let resultados = buscarProductos("categoria", e.target.textContent);
            const productos = document.querySelector(".productos");
            productos.innerHTML = "";
            // console.log(resultados);
            if (resultados != false) {
                let usuario = sessionStorage.getItem("UserLogin");
                usuario = JSON.parse(usuario);
                const template = document.getElementById("templateProducto").content;
                const fragmento = document.createDocumentFragment();
                // console.log(resultados);
                // console.log(template);

                for (let indice in resultados) {
                    if (resultados[indice]["id_vendedor"] != usuario["id"]) {
                        const clon = template.cloneNode(true);
                        let producto = resultados[indice];
                        clon.querySelector(".producto").dataset.idProducto = producto["id"];
                        clon.querySelector(".imagen-producto").src = producto["imagen_producto"];
                        clon.querySelector(".titulo-info").textContent = producto["nombre"];
                        clon.querySelector(".precio-info").textContent = "$" + producto["precio"];
                        fragmento.appendChild(clon);
                    }
                }

                productos.appendChild(fragmento);
                seleccionarProducto();
            } else {
                const template = document.getElementById("mensajeNoEncontrado").content.cloneNode(true);
                template.querySelector(".mensajeCero > h4").textContent = `┗( T﹏T )┛  No se han encontrado resultados`;
                const fragmento = document.createDocumentFragment();
                fragmento.appendChild(template);
                productos.appendChild(fragmento);
            }
        }
    });
}

function calcularDistancia() {
    let anchoTotal = 0;
    const categorias = document.querySelectorAll("#opciones-categorias > li > span");
    categorias.forEach(elemento => {
        anchoTotal += elemento.offsetWidth + 15;
    });
    console.log(anchoTotal);
    return anchoTotal;
}

function buscador() {
    const form = document.getElementById("formBuscador");
    const campoValor = document.getElementById("campo-buscar");
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        // console.log(campoValor.value);
        let resultados = buscarProductos("nombre", campoValor.value);
        const productos = document.querySelector(".productos");
        productos.innerHTML = "";
        // console.log(resultados);
        if (resultados != false) {
            let usuario = sessionStorage.getItem("UserLogin");
            usuario = JSON.parse(usuario);
            const template = document.getElementById("templateProducto").content;
            const fragmento = document.createDocumentFragment();
            // console.log(resultados);
            // console.log(template);

            for (let indice in resultados) {
                if (resultados[indice]["id_vendedor"] != usuario["id"]) {
                    const clon = template.cloneNode(true);
                    let producto = resultados[indice];
                    clon.querySelector(".producto").dataset.idProducto = producto["id"];
                    clon.querySelector(".imagen-producto").src = producto["imagen_producto"];
                    clon.querySelector(".titulo-info").textContent = producto["nombre"];
                    clon.querySelector(".precio-info").textContent = "$" + producto["precio"];
                    fragmento.appendChild(clon);
                }
            }

            productos.appendChild(fragmento);
            seleccionarProducto();
        } else {
            const template = document.getElementById("mensajeNoEncontrado").content.cloneNode(true);
            template.querySelector(".mensajeCero > h4").textContent = `┗( T﹏T )┛  No se han encontrado resultados`;
            const fragmento = document.createDocumentFragment();
            fragmento.appendChild(template);
            productos.appendChild(fragmento);
        }
    });
}


document.addEventListener("DOMContentLoaded", () => {
    main();
})