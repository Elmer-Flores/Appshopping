document.addEventListener("DOMContentLoaded", () => {
    subLista("subListaCate", true);
    subLista("subListaSesion", false);
    cargarFotoPerfil();
    cerrarSesionNav();
})