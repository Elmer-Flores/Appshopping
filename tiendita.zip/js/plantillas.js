
class Usuario {

    constructor(nombre = "", clave = "", email = "") {
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
    }

    registrar() {
        let id = 1;
        let listaObjetos = new Object();
        let nuevoUsuario = {
            "id": id,
            "nombre": this.nombre,
            "clave": this.clave,
            "email": this.email,
            "fecha": this.obtenerFecha(),
            "fotoPerfil": "img/icono/perfil2.png"
        };
        if (!localStorage.getItem("Users")) {
            listaObjetos[id] = nuevoUsuario;
            localStorage.setItem("Users", JSON.stringify(listaObjetos));
            console.log("Se ha creado un nuevo usuario");
            return true;
        } else {
            let respuestaValidacion = this.validarRegistro();
            if (respuestaValidacion == false) {
                let listaObjetos = localStorage.getItem("Users");
                listaObjetos = JSON.parse(listaObjetos);
                // id = Object.keys(listaObjetos).length;
                
                for (let indice in listaObjetos) {
                    id = listaObjetos[indice].id;
                }
                
                id = id + 1;
                nuevoUsuario.id = id;
                listaObjetos[id] = nuevoUsuario;
                localStorage.setItem("Users", JSON.stringify(listaObjetos));
                console.log("Se ha creado un nuevo usuario");
                return true;
            } else {
                console.log(`Ya existe ese usuario con ese ${respuestaValidacion}...`);
                return false;
            }
        }
    }

    validarRegistro() {
        let registros = localStorage.getItem("Users");
        registros = JSON.parse(registros);
        let respuesta = false;
        
        // validar email y nombre
        for (let indice in registros) {
            let elemento = registros[indice];
            if (elemento.email == this.email && elemento.nombre == this.nombre) {
                respuesta = "email y nombre";
            }
            else if (elemento.email == this.email) {
                respuesta = "email";
            }
            else if (elemento.nombre == this.nombre) {
                respuesta = "nombre";
            }
        }
        
        return respuesta;
    }

    obtenerFecha() {
        let tiempoActual = new Date();
        tiempoActual = `${tiempoActual.getDate()}/${tiempoActual.getMonth() + 1}/${tiempoActual.getFullYear()}`;
        return tiempoActual;
    }

    iniciarSesion() {
        let confirmar = this.verificarUsuario(this.clave, this.email);
        if ( confirmar == false ) {
            console.log("No estas registrado...");
            return false;
        } else {
            // console.log("Has iniciado sesion...");
            return true;
        }
    }

    verificarUsuario(clave, mail) {
        if (localStorage.getItem("Users")) {
            let usuarios = localStorage.getItem("Users");
            usuarios = JSON.parse(usuarios);
            let encontrado = false;
            
            for (let indice in usuarios) {
                if ( usuarios[indice].email == mail  && usuarios[indice].clave == clave) {
                    sessionStorage.setItem("UserLogin", JSON.stringify(usuarios[indice]));
                    encontrado = true;
                }
            };
            
            return encontrado;
        } else {
            return false;
        }
    }

    cerrarSesion() {
        if (sessionStorage.getItem("UserLogin")) {
            sessionStorage.removeItem("UserLogin");
            console.log("Has cerrado sesion...");
        }
    }

    eliminarCuenta() {
        if (sessionStorage.getItem("UserLogin") && localStorage.getItem("Users")) {
            let usuarioLogeado = sessionStorage.getItem("UserLogin");
            usuarioLogeado = JSON.parse(usuarioLogeado);
            let usuariosRegistrados = localStorage.getItem("Users");
            usuariosRegistrados = JSON.parse(usuariosRegistrados);
            let productos = localStorage.getItem("ProductosSubidos");
            productos = JSON.parse(productos);
            // let nuevaListaProductos = new Object();

            for (let indice in productos) {
                if (productos[indice].id_vendedor == usuarioLogeado.id) {
                    delete productos[indice];
                    // nuevaListaProductos[indice] = productos[indice];
                }
            }

            sessionStorage.removeItem("UserLogin");
            delete usuariosRegistrados[usuarioLogeado.id];
            localStorage.setItem("Users", JSON.stringify(usuariosRegistrados));
            localStorage.setItem("ProductosSubidos", JSON.stringify(productos));
            console.log("Se ha eliminado la cuenta exitosamente...");
            console.log("Se ha cerrado sesion...");
        } else {
            console.log("Tienes que haber iniciado sesion para eliminar tu cuenta...");
        }
    }

    verDatos() {
        if (sessionStorage.getItem("UserLogin")) {
            let usuarioLogeado = sessionStorage.getItem("UserLogin");
            usuarioLogeado = JSON.parse(usuarioLogeado);
            console.log(usuarioLogeado);
        } else {
            console.log("Tienes que iniciar sesion primero...");
        }
    }

    verUsuarios() {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem("Users")) {
                let usuarios = localStorage.getItem("Users");
                usuarios = JSON.parse(usuarios);
                console.log("USUARIOS REGISTRADOS: ");
                console.log(usuarios);
            } else {
                console.log("No hay usuarios registrados...");
            }
        } else {
            console.log("Tienes que iniciar sesion primero...");
        }
    }

    editarDatos(id, campo, nuevoValor) {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem("Users")) {
                let usuarios = localStorage.getItem("Users");
                usuarios = JSON.parse(usuarios);
                let userLog = sessionStorage.getItem("UserLogin");
                userLog = JSON.parse(userLog);
                if (usuarios[id].id == userLog.id) {
                    let productos = localStorage.getItem("ProductosSubidos");
                    productos = JSON.parse(productos);
                    usuarios[id][campo] = nuevoValor;
                    userLog[campo] = nuevoValor;

                    for (let indice in productos) {
                        let elemento = productos[indice];
                        if (elemento.id_vendedor == id && campo == "nombre") {
                            elemento.persona_vendedor = nuevoValor;
                        }
                    }

                    sessionStorage.setItem("UserLogin", JSON.stringify(userLog));
                    localStorage.setItem("Users", JSON.stringify(usuarios));
                    localStorage.setItem("ProductosSubidos", JSON.stringify(productos));
                    console.log("Se ha modificado un dato...");
                } else {
                    console.log("No puedes modificar datos de otros usuarios...");
                }
            } else {
                console.log("Actualmente no hay usuarios registrados...");
            }
        } else {
            console.log("Debes iniciar sesion para editar...");
        }
    }

    // EL DATAFORM ME VA A PERMITIR OBTENER TODOS LOS VALORES NUEVAMENTE Y LLEGAR HASTA LA SUBIDA DE IMAGEN
    subirProducto(nombreProducto, precio, cantidad, categoria, descripcion, rutaImagen) {
        if (sessionStorage.getItem("UserLogin")) {
            let usuario = sessionStorage.getItem("UserLogin");
            usuario = JSON.parse(usuario);
            let listaProductos = new Object();
            let id = 1;
            let producto = {
                "id": id,
                "nombre": nombreProducto,
                "precio": precio,
                "cantidad": cantidad,
                "categoria": categoria,
                "descripcion": descripcion,
                "id_vendedor": usuario.id,
                "persona_vendedor": usuario.nombre,
                "fecha_subida": this.obtenerFecha(),
                "imagen_producto": rutaImagen
            };
            if (!localStorage.getItem("ProductosSubidos")) {
                listaProductos[id] = producto;
                localStorage.setItem("ProductosSubidos", JSON.stringify(listaProductos));
            } else {
                let productosGuardados = localStorage.getItem("ProductosSubidos");
                productosGuardados = JSON.parse(productosGuardados);
                // id = Object.keys(productosGuardados).length;

                for (let indice in productosGuardados) {
                    id = productosGuardados[indice].id;
                }

                id = id + 1;
                producto.id = id;
                productosGuardados[id] = producto;
                localStorage.setItem("ProductosSubidos", JSON.stringify(productosGuardados));
            }
            console.log("Has subido un producto: ");
            console.log(producto);
        } else {
            console.log("Debes iniciar sesion para subir un producto...");
        }
    }


    // tambien puede mostrar tus productos

    verProductos(propios = false) {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem("ProductosSubidos")) {
                let productos = localStorage.getItem("ProductosSubidos");
                productos = JSON.parse(productos);
                let resultados = 0;
                if (propios == false) {
                    // console.log(`PRODUCTOS SUBIDOS: \n`);

                    for (let indice in productos) {
                        let elemento = productos[indice];
                        // console.log(elemento);
                        resultados++;
                    }

                    if (resultados == 0) {
                        return "No hay productos publicados...";
                        // console.log("No hay productos publicados...");
                    }
                    return productos;

                } else {
                    let usuario = sessionStorage.getItem("UserLogin");
                    usuario = JSON.parse(usuario);
                    // console.log("TUS PRODUCTOS:");

                    for (let indice in productos) {
                        let elemento = productos[indice];
                        if (elemento["id_vendedor"] == usuario["id"]) {
                            // console.log(elemento);
                            resultados++;
                        }
                    }

                    if (resultados == 0) {
                        return "No has publicado nada todavia...";
                        // console.log("No has publicado nada todavia...");
                    }
                    return productos;
                }

            } else {
                console.log("Actualmente no productos subidos...");
            }
        } else {
            console.log("Debes iniciar sesion para ver los productos...");
        }
    }

    eliminarProducto(id) {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem("ProductosSubidos")) {
                let usuario = sessionStorage.getItem("UserLogin");
                usuario = JSON.parse(usuario);
                let productos = localStorage.getItem("ProductosSubidos");
                productos = JSON.parse(productos);
                let coincidencia;
                let perteneciente = false;

                for (let indice in productos) {
                    if (usuario["id"] == productos[indice]["id_vendedor"] && id == productos[indice]["id"]) {
                        // delete productos[indice];
                        coincidencia = indice;
                        perteneciente = true;
                    }
                }

                if (perteneciente == true) {
                    delete productos[coincidencia];
                    localStorage.setItem("ProductosSubidos", JSON.stringify(productos));
                    console.log("Se ha eliminado un producto...");
                    return productos;
                } else {
                    console.log("No puedes eliminar productos de otros usuarios...");
                }
            } else {
                console.log("No hay productos subidos...");
            }
        } else {
            console.log("Debes iniciar sesion para eliminar un producto...");
        }
    }

    editarProducto(id, campo, nuevoValor, tipoRegistro) {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem("ProductosSubidos")) {
                let usuario = sessionStorage.getItem("UserLogin");
                usuario = JSON.parse(usuario);
                let productos = localStorage.getItem(tipoRegistro);
                // let productos = localStorage.getItem("ProductosSubidos");
                productos = JSON.parse(productos);
                let perteneciente = false;

                for (let indice in productos) {
                    let elemento = productos[indice];
                    if (elemento["id"] == id && elemento["id_vendedor"] == usuario["id"]) {
                        elemento[campo] = nuevoValor;
                        perteneciente = true;
                    }
                }

                if (perteneciente == true) {
                    localStorage.setItem("ProductosSubidos", JSON.stringify(productos));
                    console.log("Se ha modificado un producto...");
                } else {
                    console.log("No puedes modificar productos de otros usuarios...");
                }
            } else {
                console.log("No hay productos subidos...");
            }
        } else {
            console.log("Debes iniciar sesion para editar un producto...");
        }
    }

    // funciona para usuarios y productos
    buscar(campo, valor, tipoRegistro) {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem(tipoRegistro)) {
                let lista = localStorage.getItem(tipoRegistro);
                lista = JSON.parse(lista);
                let valorCon;
                let coincidencia = false;
                // console.log("RESULTADOS DE BUSQUEDA: ");

                for (let indice in lista) {
                    if (lista[indice][campo] == valor) {
                        coincidencia = true;
                        // console.log(lista[indice]);
                        valorCon = lista[indice];
                    }
                }

                if (coincidencia == false) {
                    console.log("No hay resultados...");
                    return false;
                }
                return valorCon;
            } else {
                console.log("No hay resultados...");
                return false;
            }

        } else {
            console.log("Tienes que iniciar sesion primero...");
            return false;
        }
    }


    busquedaAvanzada(campo, valor, tipoRegistro) {
        if (sessionStorage.getItem("UserLogin")) {
            if (localStorage.getItem(tipoRegistro)) {
                let lista = localStorage.getItem(tipoRegistro);
                lista = JSON.parse(lista);
                let results = new Object();
                let coincidencia = false;
                // console.log("RESULTADOS DE BUSQUEDA: ");

                for (let indice in lista) {
                    let temp = `${lista[indice][campo]}`.toUpperCase();
                    let tem = `${valor}`.toUpperCase();
                    if ( temp == tem) {
                        coincidencia = true;
                        // console.log(lista[indice]);
                        results[indice] = lista[indice];
                    }
                }

                if (coincidencia == false) {
                    console.log("No hay resultados...");
                    return false;
                }
                return results;
            } else {
                console.log("No hay resultados...");
                return false;
            }

        } else {
            console.log("Tienes que iniciar sesion primero...");
            return false;
        }
    }

    

    // guardarHistorial(idPersonaRelacionada, idProducto, tipoRegistro, cantidadComprada=0) {
    //     let usuario = JSON.parse( sessionStorage.getItem("UserLogin") );
    //     let userRel = this.buscar("id", idPersonaRelacionada, "Users");
    //     let producto = this.buscar("id", idProducto, "ProductosSubidos");
    //     let historialUno = new Object();
    //     let id = 1;
    //     producto["idCompra"] = id;
    //     if ( localStorage.getItem(tipoRegistro) ) {
    //         let comprasList = JSON.parse(localStorage.getItem(tipoRegistro));
    //         for ( let indice in comprasList) { 
    //             id = comprasList[indice]["idCompra"];
    //         }; 
    //         id++;
    //         comprasList[id] = producto;
    //         localStorage.setItem(tipoRegistro, JSON.stringify(comprasList));
    //     } else {
    //         historialUno[id] = producto;
    //         localStorage.setItem(tipoRegistro, JSON.stringify(historialUno));
    //     }
    //     // let historialDos = new Object();
    // }


    obtenerEquidad(registro1="Compras", registro2="ComprasB") {
        let res1 = JSON.parse(localStorage.getItem(registro1));
        let res2 = JSON.parse(localStorage.getItem(registro2));
        let indices = [1, 1];
        
        for ( let indice in res1 ) {
            indices[0] = res1[indice]["idCompras"];
        }
        
        for ( let indice in res2 ) {
            indices[1] = res2[indice]["idCompras"];
        }
        
        return indices; // id ultimos de sus registros
    }


    guardarHistorial(idPersonaRelacionada, idProducto, tipoRegistro, cantidadComprada=0) {
        if ( localStorage.getItem("ProductosSubidos") ) {
            let usuario = JSON.parse( sessionStorage.getItem("UserLogin") );
            let userRel = this.buscar("id", idPersonaRelacionada, "Users");
            let producto = this.buscar("id", idProducto, "ProductosSubidos");
            let historialDeTransacciones = new Object();
            // let id = 1;
            let ids = this.obtenerEquidad();
            let id = ids[0];
            producto[`fecha${tipoRegistro}`] = this.obtenerFecha();

            // SON NUEVAS ADICIONES PARA MEJORAR EL HISTORIAL
            let historialCopia = new Object();
            let idPertenecienteOtro;
            let producto2 = Object.assign(producto);
            idPertenecienteOtro = producto2["id_vendedor"];
            producto[`ìdPerteneciente`] = usuario["id"];
            // idPertenecienteOtro = indices[1];

            producto[`id${tipoRegistro}`] = id; 
            producto["cantidad"] = cantidadComprada;
            producto["costoTotal"] = producto["cantidad"] * producto["precio"];
            if ( tipoRegistro == "Compras" ) {
                producto["persona_vendedor"] = userRel["nombre"];
                producto["persona_comprador"] = usuario["nombre"];
            } else if ( tipoRegistro == "Ventas" ) {
                producto["persona_comprador"] = userRel["nombre"];
                producto["persona_vendedor"] = usuario["nombre"];
            }
            
            if ( localStorage.getItem(tipoRegistro) ) {
                let existentes = JSON.parse(localStorage.getItem(tipoRegistro));
                
                for ( let indice in existentes ) {
                    id = existentes[indice][`id${tipoRegistro}`]; 
                    // existentes[indice][`ìd${tipoRegistro}`] = id; 
                    historialDeTransacciones[indice] = existentes[indice];
                    historialDeTransacciones[indice]["idPerteneciente"] = usuario["id"];
                    historialCopia[indice] = existentes[indice];
                }
                
                id = id + 1;
                producto[`id${tipoRegistro}`] = id; 
                historialDeTransacciones[id] = producto;
                
                localStorage.setItem(tipoRegistro, JSON.stringify(historialDeTransacciones) );

                // producto[`id${tipoRegistro}`] = ids[1]; 
                producto2["ìdPerteneciente"] = idPertenecienteOtro;
                historialCopia[id] = producto2;
                localStorage.setItem("ComprasB", JSON.stringify(historialCopia) );
                return true;
            } else {
                historialDeTransacciones[id] = producto;
                localStorage.setItem(tipoRegistro, JSON.stringify(historialDeTransacciones) );

                // producto[`id${tipoRegistro}`] = ids[1]; 
                producto2["ìdPerteneciente"] = idPertenecienteOtro;
                historialCopia[id] = producto2;
                localStorage.setItem("ComprasB", JSON.stringify(historialCopia) );
                return true;
            }
        } else {
            return false;
        }
    }


    // guardarHistorial(idPersonaRelacionada, idProducto, tipoRegistro, cantidadComprada=0) {
    //     if ( localStorage.getItem("ProductosSubidos") ) {
    //         // if ( localStorage.getItem("Compras") || localStorage.getItem("ComprasB") ) {

    //         // } else {

    //         // }
    //         let usuario = JSON.parse( sessionStorage.getItem("UserLogin") );
    //         let userRel = this.buscar("id", idPersonaRelacionada, "Users");
    //         let producto = this.buscar("id", idProducto, "ProductosSubidos");
    //         let historialDeTransacciones = new Object();
    //         let id = 1;
    //         producto[`fecha${tipoRegistro}`] = this.obtenerFecha();

    //         // SON NUEVAS ADICIONES PARA MEJORAR EL HISTORIAL
    //         let historialCopia = new Object();
    //         let idPertenecienteOtro;
    //         let producto2 = Object.assign(producto);
    //         producto[`ìdPerteneciente`] = usuario["id"];
    //         idPertenecienteOtro = producto2["id_vendedor"];

    //         producto[`id${tipoRegistro}`] = id; 
    //         producto["cantidad"] = cantidadComprada;
    //         producto["costoTotal"] = producto["cantidad"] * producto["precio"];
    //         // producto["costoTotal"] = cantidadComprada * producto["precio"];
    //         if ( tipoRegistro == "Compras" ) {
    //             producto["persona_vendedor"] = userRel["nombre"];
    //             producto["persona_comprador"] = usuario["nombre"];
    //         } else if ( tipoRegistro == "Ventas" ) {
    //             producto["persona_comprador"] = userRel["nombre"];
    //             // producto["persona_comprador"] = producto["persona_vendedor"];
    //             producto["persona_vendedor"] = usuario["nombre"];
    //         }
            
    //         if ( localStorage.getItem(tipoRegistro) ) {
    //             let existentes = JSON.parse(localStorage.getItem(tipoRegistro));
                
    //             for ( let indice in existentes ) {
    //                 id = existentes[indice][`id${tipoRegistro}`]; 
    //                 // existentes[indice][`ìd${tipoRegistro}`] = id; 
    //                 historialDeTransacciones[indice] = existentes[indice];

    //                 historialCopia[indice] = existentes[indice];
    //             }
                
    //             id = id + 1;
    //             producto[`id${tipoRegistro}`] = id; 
    //             historialDeTransacciones[id] = producto;

                
    //             localStorage.setItem(tipoRegistro, JSON.stringify(historialDeTransacciones) );

    //             producto2["ìdPerteneciente"] = idPertenecienteOtro;
    //             historialCopia[id] = producto2;
    //             localStorage.setItem("ComprasB", JSON.stringify(historialCopia) );
    //             // return historialDeTransacciones;
    //             return true;
    //         } else {
    //             // producto[`ìd${tipoRegistro}`] = id; 
    //             historialDeTransacciones[id] = producto;

    //             localStorage.setItem(tipoRegistro, JSON.stringify(historialDeTransacciones) );

    //             producto2["ìdPerteneciente"] = idPertenecienteOtro;
    //             historialCopia[id] = producto2;
    //             localStorage.setItem("ComprasB", JSON.stringify(historialCopia) );
    //             // return historialDeTransacciones;
    //             return true;
    //         }
    //     } else {
    //         return false;
    //     }
    // }

    verHistorial(tipoRegistro="Compras", tipoRegistro2="ComprasB") {
        if ( localStorage.getItem(tipoRegistro) || localStorage.getItem(tipoRegistro2) ) {
            let compras = JSON.parse(localStorage.getItem(tipoRegistro));
            let compras2 = JSON.parse(localStorage.getItem(tipoRegistro2));
            let userTemp = JSON.parse(sessionStorage.getItem("UserLogin"));
            
            let pertenecienteTipoRegistro = 0; 
            
            for ( let indice in compras ) {
                if ( compras[indice]["ìdPerteneciente"] == userTemp["id"] ) {
                    pertenecienteTipoRegistro = 1;
                }
            }
            
            for ( let indice in compras2 ) {
                if ( compras2[indice]["ìdPerteneciente"] == userTemp["id"] ) {
                    pertenecienteTipoRegistro = 2;
                }
            }
            
            if ( pertenecienteTipoRegistro == 1 ) {
                return Array(JSON.parse( localStorage.getItem(tipoRegistro) ) , true );
                // return JSON.parse( localStorage.getItem(tipoRegistro) );
            } else if ( pertenecienteTipoRegistro == 2 ) {
                return Array(JSON.parse( localStorage.getItem(tipoRegistro2) ) , false) ;
                // return JSON.parse( localStorage.getItem(tipoRegistro2) );
            } else {
                return false;
            }
            
        }
        return false;
    }

    limpiarHistorial(tipoRegistro, nombreHistorial="Compras", nombreHistorial2="ComprasB"){
        if ( localStorage.getItem(nombreHistorial) ) {
            // let user = JSON.parse( sessionStorage.getItem("UserLogin") );
            // let historiales = JSON.parse( localStorage.getItem(nombreHistorial) );
            let historialesArray = this.verHistorial();
            let historiales = historialesArray[0];
            let nuevoHistoriales = new Object();
            let user = JSON.parse(sessionStorage.getItem("UserLogin"));
            let counValid = 0;
            // if ( tipoRegistro == "compra" ) {
            //     console.log("Compras");
            // } else {
            //     console.log("Ventas");
            // }
            for ( let indice in historiales ) {
                if ( tipoRegistro == "compra" && user["nombre"] != historiales[indice]["persona_comprador"] ) {
                    // console.log(historiales[indice]);
                    nuevoHistoriales[indice] = historiales[indice];
                    counValid++;
                } else if ( tipoRegistro == "venta" && user["nombre"] != historiales[indice]["persona_vendedor"] ) {
                    // console.log(historiales[indice]);
                    nuevoHistoriales[indice] = historiales[indice];
                    counValid++;
                }
            }
            
            if ( counValid != 0 ) {
                if ( historialesArray[1] == true ) {
                    localStorage.setItem(nombreHistorial, JSON.stringify(nuevoHistoriales) );
                } else {
                    localStorage.setItem(nombreHistorial2, JSON.stringify(nuevoHistoriales) );
                }
                return false;
            } else {
                if ( historialesArray[1] == true ) {
                    localStorage.removeItem(nombreHistorial);
                } else {
                    localStorage.removeItem(nombreHistorial2);
                }
                // localStorage.removeItem(nombreHistorial);
            }

            // localStorage.removeItem(tipoRegistro);
            
            return true;
        }
        return false;
    }

}






// let nuevoUser = new Usuario("Elmer", "contra1", "elmer@gmail.com");