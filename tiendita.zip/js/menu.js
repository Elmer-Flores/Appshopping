// FUNCION PARA VER SUBLISTA

function subLista(idSelect, op = true) {
    const cuerpo = document.getElementById("cuerpoPag");
    const sub = document.getElementById(idSelect);
    cuerpo.addEventListener("click", (e) => {
        let elemento = e.target.tagName;
        let eTar = e.target.id;
        if ( op == true) {
            if ( (elemento == "SPAN" && eTar == "abrirSub") || ( elemento == "I" && eTar == "car-ico") ) {
                sub.classList.toggle("mantenido");
            } else {
                sub.classList.remove("mantenido");
            }
        } else {
            if ( (elemento == "SPAN" && eTar == "abrirSubSesion") || ( elemento == "I" && eTar == "car-icoSesion") ) {
                sub.classList.toggle("mantenido");
            } else if ( elemento == "IMG" && eTar == "imgPerfil" ) {
                sub.classList.toggle("mantenido");
            } else {
                sub.classList.remove("mantenido");
            }
        }
    });
}

function cerrarSesionNav(){
    const btnLink = document.getElementById("cerrarSesionLink");
    btnLink.addEventListener("click", (e) => {
        e.preventDefault();
        sessionStorage.removeItem("UserLogin");
        if ( localStorage.getItem("productoSeleccionado") ) {
            localStorage.removeItem("productoSeleccionado");
        }
        window.location = "index.html";
    });
}

function cargarFotoPerfil() {
    const imagen = document.getElementById("imgPerfil");
    let user = JSON.parse(sessionStorage.getItem("UserLogin"));
    imagen.src = user["fotoPerfil"];
}