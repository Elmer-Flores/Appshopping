

function main() {
    if (sessionStorage.getItem("UserLogin")) {
        cargarDatosPersonales();
        subLista("subListaCate", true);
        subLista("subListaSesion", false);
        cargarFotoPerfil();
        cerrarSesionNav();
        editarPerfil();
        if (localStorage.getItem("ProductosSubidos")) {
            cargarDatos();
            seleccionProductos();
            if (localStorage.getItem("Compras") || localStorage.getItem("ComprasB")) {
                let res1 = cargarHistorial("cuerpo-tabla-compras", "Compras", false);
                let res2 = cargarHistorial("cuerpo-tabla-ventas", "Compras", true);
                if (res1 == 0) {
                    cargarMensajeVacio("cuerpo-tabla-compras", "No has comprado nada todavia", false, false);
                }
                if (res2 == 0) {
                    cargarMensajeVacio("cuerpo-tabla-ventas", "No has vendido nada todavia", false, true);
                }
            } else {
                cargarMensajeVacio("cuerpo-tabla-compras", "No has comprado nada todavia", false, false);
                cargarMensajeVacio("cuerpo-tabla-ventas", "No has vendido nada todavia", false, true);
            }
            limpiarTabla(".btn-limpiar-ventas", "cuerpo-tabla-ventas", "venta", "No has vendido nada todavia", true);
            limpiarTabla(".btn-limpiar-compras", "cuerpo-tabla-compras", "compra", "No has comprado nada todavia", false);
        } else {
            console.log("No has subido ninguno todavia");
        }
    } else {
        window.location = "index.html";
    }
}


function cargarDatosPersonales() {
    let userLog = sessionStorage.getItem("UserLogin");
    userLog = JSON.parse(userLog);
    let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
    persona.iniciarSesion();

    const datosPerfil = document.querySelector(".tarjeta-perfil");
    const templateOriginalPerfil = document.getElementById("datosPerfil").content;
    const fragmentoPerfil = document.createDocumentFragment();
    const templatePerfil = templateOriginalPerfil.cloneNode(true);
    templatePerfil.querySelector(".imagen-perfil").src = userLog["fotoPerfil"];
    templatePerfil.querySelector(".nombre").textContent = userLog["nombre"];
    templatePerfil.querySelector(".email").textContent = userLog["email"];
    templatePerfil.querySelector(".fecha-subida").textContent = "Fecha de creación: " + userLog["fecha"];
    fragmentoPerfil.appendChild(templatePerfil);
    datosPerfil.appendChild(fragmentoPerfil);
}

function cargarHistorial(idCuerpoTabla, tipoRegistro="Compras", muestra=false) {
    let userLog = sessionStorage.getItem("UserLogin");
    userLog = JSON.parse(userLog);
    let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
    persona.iniciarSesion();
    const datosHistorial = document.querySelector(`#${idCuerpoTabla}`);
    const templateOriginalTabla = document.getElementById("contenidoTablaCuerpo").content;
    const fragmento = document.createDocumentFragment();
    let countComfirm = 0;
    let historialArray = persona.verHistorial(tipoRegistro, "ComprasB");
    let historial = historialArray[0];

    for (let indice in historial) {
        
        if ((historial[indice]["persona_vendedor"] == userLog["nombre"] && muestra == true) ||
            (historial[indice]["persona_comprador"] == userLog["nombre"] && muestra == false)) {
            const template = templateOriginalTabla.cloneNode(true);
            
            template.querySelector(".imagen-campo").src = historial[indice]["imagen_producto"];
            template.querySelector(".nombre").textContent = historial[indice]["nombre"];
            template.querySelector(".categoria").textContent = historial[indice]["categoria"];
            template.querySelector(".precio").textContent = `$${historial[indice]["precio"]}`;
            template.querySelector(".cantidad").textContent = historial[indice]["cantidad"];
            template.querySelector(".fecha").textContent = historial[indice][`fecha${tipoRegistro}`];
            template.querySelector(".total").textContent = `$${historial[indice]["costoTotal"]}`;
            
            if (muestra == false) {
                template.querySelector(".persona").textContent = historial[indice]["persona_vendedor"];
            } else {
                template.querySelector(".persona").textContent = historial[indice]["persona_comprador"];
            }
            
            fragmento.appendChild(template);
            countComfirm++;
        }
    }
    
    datosHistorial.appendChild(fragmento);
    return countComfirm;
}

function limpiarTabla(btn, tabla, nameHis, mensajeVac, muestraThis) {
    const btnLimpiar = document.querySelector(btn);
    btnLimpiar.addEventListener("click", () => {
        let userLog = sessionStorage.getItem("UserLogin");
        userLog = JSON.parse(userLog);
        let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
        persona.iniciarSesion();
        persona.limpiarHistorial(nameHis);
        document.querySelector(`#${tabla}`).innerHTML = "";
        cargarMensajeVacio(tabla, mensajeVac, false, muestraThis);
    });
}

function cargarMensajeVacio(idCuerpoTabla, mensaje, reponer = false, muestra = false) {
    let userLog = JSON.parse(sessionStorage.getItem("UserLogin"));
    // let comp = JSON.parse(localStorage.getItem("Compras"));
    let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
    persona.iniciarSesion();
    let compArray = persona.verHistorial("Compras", "ComprasB");
    let comp = compArray[0];
    let coin = 0;

    for (let indice in comp) {
        if ((comp[indice]["persona_vendedor"] == userLog["nombre"] && muestra == true && reponer == true) ||
            (comp[indice]["persona_comprador"] == userLog["nombre"] && muestra == false && reponer == true)) {
            coin++;
        }
    }

    const padre = document.getElementById(idCuerpoTabla);
    const template = document.getElementById("mensjaeVacioTabla").content.cloneNode(true);
    const fragmento = document.createDocumentFragment();
    template.querySelector("span").textContent = mensaje;
    fragmento.appendChild(template);

    if (coin != 0 && reponer == true) {
        padre.innerHTML = "";
        padre.appendChild(fragmento);
    } else if (reponer == false) {
        padre.appendChild(fragmento);
    }
}

function cargarDatos() {
    let userLog = sessionStorage.getItem("UserLogin");
    userLog = JSON.parse(userLog);
    let persona = new Usuario(userLog["nombre"], userLog["clave"], userLog["email"]);
    persona.iniciarSesion();

    let productos = persona.verProductos(true);

    const mainCont = document.querySelector(".productos");
    mainCont.innerHTML = "";
    const templateOriginal = document.getElementById("templateProductoPerfil").content;
    const fragmento = document.createDocumentFragment();

    for (let indice in productos) {
        let producto = productos[indice];
        if (producto["id_vendedor"] == userLog["id"]) {
            const template = templateOriginal.cloneNode(true);
            template.querySelector(".producto").dataset.idProducto = producto["id"];
            template.querySelector(".imagen-producto").src = producto["imagen_producto"];
            template.querySelector(".titulo-info").textContent = producto["nombre"];
            template.querySelector(".precio-info").textContent = "$" + producto["precio"];
            fragmento.appendChild(template);
        }
    }

    mainCont.appendChild(fragmento);
}

function seleccionProductos() {
    const productos = document.querySelectorAll(".producto");
    productos.forEach(elemento => {
        elemento.addEventListener("click", () => {
            let productoPublicados = JSON.parse(localStorage.getItem("ProductosSubidos"));
            let idProductoSeleccionado = elemento.dataset.idProducto;
            // console.log(elemento.dataset.idProducto);
            console.log(productoPublicados[idProductoSeleccionado]);
            localStorage.setItem("ProductoModificar", JSON.stringify(productoPublicados[idProductoSeleccionado]));
            window.location = "editar-producto.html";
        });
    });
}

function editarPerfil(){
    const btnEditar = document.querySelector(".btn-editar-perfil");
    btnEditar.addEventListener("click", () => {
        let userLog = JSON.parse(sessionStorage.getItem("UserLogin"));
        localStorage.setItem("UsuarioEdicion", JSON.stringify(userLog));
        window.location = "editar-perfil.html";
    });
}

document.addEventListener("DOMContentLoaded", () => {
    main();
})