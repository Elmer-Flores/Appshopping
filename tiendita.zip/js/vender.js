
function main() {
    if ( sessionStorage.getItem("UserLogin") ) {
        let usuario = sessionStorage.getItem("UserLogin");
        usuario = JSON.parse(usuario);
        subLista("subListaCate", true);
        subLista("subListaSesion", false);
        cargarFotoPerfil();
        cerrarSesionNav();
        imagenDeVistaPrevia();
        realizarForm();
    } else {
        window.location = "index.html";
    }
} 

// FUNCIONES PARA EL FORMULARIO
function imagenDeVistaPrevia() {
    let anterior;
    const form = document.getElementById("formPublicacion");
    const botonImagen = document.getElementById("imagenProducto");
    const imagen = document.getElementById("imagenPrevia");
    botonImagen.addEventListener("change", (e) => {
        anterior = imagen.src;
        try{            
            let reader = new FileReader();
            reader.readAsDataURL(e.target.files[0]);
            reader.addEventListener("load", () => {
                imagen.src = reader.result;
            });
        }catch (error) {
            imagen.src = anterior;
        }
    });

    // Otra opcion no mantenida al 100%
    // botonImagen.addEventListener("change", () => {
    //     let data = new FormData(form);
    //     let file = data.get("imagenProducto");
    //     let url = URL.createObjectURL(file);
    //     imagen.setAttribute("src", url);
    // });
}

function validarCampo(id) {
    const campo = document.getElementById(id).value;
    if ( campo != null && campo != undefined && campo != "" && campo != " " ) {
        return campo;
    }
    return false;
}

function realizarForm(){
    const formulario = document.getElementById("formPublicacion");
    formulario.addEventListener("submit", (e) => {
        e.preventDefault();
        let usuario = sessionStorage.getItem("UserLogin");
        usuario = JSON.parse(usuario);
        let userObj = new Usuario(usuario["nombre"], usuario["clave"], usuario["email"]);
        userObj.iniciarSesion();
        let nombre = validarCampo("nombreProducto");
        let precio = validarCampo("precioProducto");
        let categoria = validarCampo("categoriaProducto");
        let descripcion = validarCampo("descripcionProducto");
        let cantidad = validarCampo("cantidadProducto");
        let imagen = document.getElementById("imagenPrevia").src;
        if ( nombre != false && precio != false && categoria != false  && descripcion != false && cantidad != false) {
            try{                
                userObj.subirProducto(nombre, precio, cantidad, categoria, descripcion, imagen);
                console.log("Has publicado un producto...");
                formulario.reset();
            } catch (error) {
                imagen = "img/icono/producto.PNG";
            }
        } else {
            console.log("No has completado bien los campos...");
        }
    });
}


document.addEventListener("DOMContentLoaded", () => {
    main();
})