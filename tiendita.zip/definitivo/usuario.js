

class User{

    constructor( nombre, clave, email ) {
        this.nombre = nombre;
        this.clave = clave;
        this.email = email;
    }

    registrar() {
        if ( sessionStorage.getItem("UserLogin") ) {
            let usuarios = JSON.parse( localStorage.getItem("Users") );
            const nuevoUser = {
                "nombre": this.nombre,
                "clave": this.clave,
                "email": this.email
            };
        } else {
            return false;
        }
    }

}